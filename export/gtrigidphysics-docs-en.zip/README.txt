GTRigidPhysics - documentation sources (en)
70 Markdown files, exported from https://gtedd.github.io/GTRigidPhysics

Layout mirrors docs/ in the repository, so a file here maps 1:1 onto
the file you would edit in a pull request.

The YAML front matter is kept on purpose. A translation records which
revision of the original it was made from (i18n_source_sha); the
repository's checks read that field, and the site uses it to flag
translations that have fallen behind. Do not strip it.

Pages with no translation yet fall back to the source language, so
this bundle contains text in the original language. That is expected
-- those are the pages still up for grabs. To translate one, add the
language suffix to its name and place it next to the original:
guide/quick-start.md becomes guide/quick-start.en.md

Translation guide: https://gtedd.github.io/GTRigidPhysics/en/dev/translating/
Source repository: https://github.com/GTedd/GTRigidPhysics
