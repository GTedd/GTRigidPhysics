GTRigidPhysics - documentation sources (zh)
70 Markdown files, exported from https://gtedd.github.io/GTRigidPhysics

Layout mirrors docs/ in the repository, so a file here maps 1:1 onto
the file you would edit in a pull request.

The YAML front matter is kept on purpose. A translation records which
revision of the original it was made from (i18n_source_sha); the
repository's checks read that field, and the site uses it to flag
translations that have fallen behind. Do not strip it.

This is the source language. Every file here is an original, not a
translation. If you are translating, you probably want the bundle
for your target language instead -- switch the language at the top
of the site and export again from there. Its untranslated pages
will show up as these same Chinese originals, which is exactly the
set of pages still up for grabs.

Translation guide: https://gtedd.github.io/GTRigidPhysics/dev/translating/
Source repository: https://github.com/GTedd/GTRigidPhysics
